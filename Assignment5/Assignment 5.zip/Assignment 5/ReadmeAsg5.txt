Assignment 5 - Khoa
I chose option 1 for this assignment.

- Use Foafamatic site to build a .rdf file of you and your friends. 
     In this RDF I built my name and three friends: Nhung Ho, Mary Waslt and John Smith
   (See the FOAFFriendsKhoaWeb.txt)
- Use Protege to build an .owl file of a few more friends,
 with some of them same as the FOAF friends. I added five more friends:
  Tran Ho, Honag Ho, Miss. Ho, Katherin Waslt, and Tuyen Ho

See the two screen-shot pictures for the result. Jena combines these two different data sources 

